import pkg from "pg";
const { Pool } = pkg;

if (!process.env.DATABASE_URL) {
  console.error("❌ DATABASE_URL missing in db/index.ts");
  throw new Error("DATABASE_URL not loaded");
}

console.log("🔍 DB URL IN USE:", process.env.DATABASE_URL);

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: false
});

// 🔥 CRITICAL FIX — restore default export:
//   All your routes & services expect `import pool from "..."`
export default pool;
