import pool from '../db/index.js';
import aiTipGenerator from './aiTipGenerator.js';
import liveStatusService from './liveStatusService.js';

// --- CORE SERVICES ---
import catalystHunterService from './catalystHunterService.js';
import macroRegimeService from './macroRegimeService.js';
import socialSentimentService from './socialSentimentService.js';
import tradeManagementService from './tradeManagementService.js';
import marketDataService from './marketDataService.js';
import tribunalService from './tribunalService.js';
import gammaExposureService from './gammaExposureService.js';
import insiderIntentService from './insiderIntentService.js';
import narrativePressureService from './narrativePressureService.js';
import currencyShockService from './currencyShockService.js';
import divergenceDetectorService from './divergenceDetectorService.js';
import multiAgentValidationService from './multiAgentValidationService.js';
import marketSentimentService from './marketSentimentService.js';
import shadowLiquidityService from './shadowLiquidityService.js';
import regimeTransitionService from './regimeTransitionService.js';
import riskConstraintService from './riskConstraintService.js';
import sectorDiscoveryService from './sectorDiscoveryService.js';
import expandedSocialService from './expandedSocialService.js';
import retailInterpretabilityService from './retailInterpretabilityService.js';
import storyModeService from './storyModeService.js';
import tradeArchitectService from './tradeArchitectService.js';
import technicalIndicatorsService from './technicalIndicatorsService.js';
import financialHealthService from './financialHealthService.js'; // NEW FSI

class ComprehensiveDataEngine {
  
  async runComprehensiveCollection() {
    console.log('🧠 STARTING V113.0-FSI ALPHA ENGINE...');
    
    await liveStatusService.update('ai_analyst', 'scanning', 'Phase 1: Ingestion');
    await (await import('./masterIngestionService.js')).default.runFullIngestion();
    
    try {
      const universe = await sectorDiscoveryService.getExpandedUniverse();
      const shuffled = universe.sort(() => 0.5 - Math.random());
      const targetTickers = shuffled.slice(0, 50);

      const trending = await socialSentimentService.getTrendingTickers(20);
      const trendingTickers = trending.map((t: any) => t.ticker);
      
      const analysisSet = [...new Set([...targetTickers, ...trendingTickers])];
      console.log(`   🔍 Deep Brain scanning ${analysisSet.length} diverse tickers...`);

      const hypotheses = analysisSet.map(ticker => ({
          ticker,
          action: 'BUY',
          thesis: `Wide-Net Discovery: Analyzing ${ticker} for potential setups.`,
          base_confidence: 50,
          tier: 'sector_play',
          category: 'Deep Scan'
      }));

      await this.processHypotheses(hypotheses);
      await tradeManagementService.reviewPositions();

      return { success: true, count: hypotheses.length };

    } catch (error: any) {
      console.error('❌ Engine Failed:', error);
      return { success: false, error: error.message };
    }
  }

  async analyzeSpecificTickers(tickers: string[]): Promise<any[]> {
      console.log(`   🔍 Deep Brain: Targeted analysis on ${tickers.length} assets...`);
      
      let regime, sentiment, fxShock;
      try {
          [regime, sentiment, fxShock] = await Promise.all([
              regimeTransitionService.detectRegime().catch(() => ({ current_regime: 'NEUTRAL', favored_sectors: [], avoid_sectors: [] })),
              marketSentimentService.getThermometer().catch(() => ({ regime: 'NEUTRAL' })),
              currencyShockService.analyzeShock().catch(() => ({ shock_level: 'LOW', sector_impacts: { beneficiaries: [], victims: [] } }))
          ]);
      } catch(e) {
          regime = { current_regime: 'NEUTRAL' }; sentiment = { regime: 'NEUTRAL' }; fxShock = { shock_level: 'LOW' };
      }

      const results = [];

      for (const ticker of tickers) {
          try {
              const [
                  agents, fractal, tribunal, narrative, insider, gamma, shadow, risk, technicals, fsi
              ] = await Promise.all([
                  multiAgentValidationService.validate(ticker).catch(() => ({ consensus: 'HOLD', agents: {} })),
                  divergenceDetectorService.analyzeFractals(ticker).catch(() => ({ has_divergence: false })),
                  tribunalService.conductTrial(ticker).catch(() => ({ final_verdict: 'HOLD' })),
                  narrativePressureService.calculatePressure(ticker).catch(() => ({ pressure_score: 50 })),
                  insiderIntentService.analyzeIntent(ticker).catch(() => ({ classification: 'UNKNOWN' })),
                  gammaExposureService.analyze(ticker).catch(() => ({ volatility_regime: 'NEUTRAL' })),
                  shadowLiquidityService.scanShadows(ticker).catch(() => ({ bias: 'NEUTRAL' })),
                  riskConstraintService.checkFit(ticker).catch(() => ({ passed: true })),
                  technicalIndicatorsService.getTechnicalIndicators(ticker).catch(() => ({ momentumProfile: 'Medium' })),
                  financialHealthService.analyze(ticker).catch(() => ({ traffic_light: 'YELLOW', quality_score: 50 })) // NEW
              ]);

              let action = 'HOLD';
              let confidence = 50;
              let reason = [];

              // FSI Gating: If Financials RED, hard cap confidence unless specific catalyst override
              if (fsi.traffic_light === 'RED') {
                  confidence = Math.min(confidence, 40);
                  reason.push('Poor Financial Health');
              } else if (fsi.traffic_light === 'GREEN') {
                  confidence += 10;
                  reason.push('Strong Financials');
              }

              if (tribunal.final_verdict === 'BUY' && agents.consensus.includes('BUY')) {
                  action = 'BUY';
                  confidence = 85;
                  reason.push('Tribunal & Agents Agree');
              } else if (tribunal.final_verdict === 'SELL') {
                  action = 'SELL';
                  confidence = 80;
                  reason.push('Sell Signal');
              }

              if (insider.classification === 'OPPORTUNISTIC') { confidence += 10; reason.push('Insider Buying'); }
              if (shadow.bias === 'ACCUMULATION') { confidence += 10; reason.push('Dark Pool Buying'); }
              if (fractal.has_divergence) { confidence += 5; reason.push('Technical Divergence'); }

              const quote = await marketDataService.getStockPrice(ticker);
              const price = quote ? quote.price : 0;

              // PHFA Layer
              const phfaPlan = tradeArchitectService.constructPlan(
                  ticker, price, confidence, (technicals?.momentumProfile as any) || 'Medium',
                  'sector_play', { gamma, insider, narrative }
              );

              const analysisObj = {
                  ticker,
                  action,
                  confidence: Math.min(99, confidence),
                  reasoning: reason.join(', ') || 'Neutral Hold',
                  targetPrice: phfaPlan.take_profit_1,
                  stopLoss: phfaPlan.stop_loss,
                  current_price: price,
                  phfa_data: phfaPlan,
                  analysis: {
                      agents: agents.consensus,
                      tribunal: tribunal.final_verdict,
                      insider: insider.classification,
                      narrative: narrative.pressure_score,
                      shadow: shadow.bias,
                      gamma: gamma.volatility_regime,
                      financials: fsi.traffic_light, // Expose to UI
                      story: ''
                  },
                  decision_matrix: {
                      engines: { narrative, shadow, gamma, insider, agents, fractal, regime, fsi }
                  },
                  retail_badges: [] as any[]
              };

              analysisObj.retail_badges = retailInterpretabilityService.generateSimpleTags(analysisObj);
              analysisObj.analysis.story = await storyModeService.generateStory(ticker, analysisObj);

              results.push(analysisObj);

          } catch (e: any) {
              console.error(`      ❌ Failed to analyze ${ticker}:`, e.message);
          }
      }
      return results;
  }

  private async processHypotheses(hypotheses: any[]) {
      const results = await this.analyzeSpecificTickers(hypotheses.map(h => h.ticker));
      const validSignals = results.filter(r => r.action !== 'HOLD' && r.confidence > 65);
      
      if (validSignals.length > 0) {
          await aiTipGenerator.processDeepBrainRecommendations(validSignals);
          await liveStatusService.update('ai_analyst', 'new_data', `Signals: ${validSignals.length}`, validSignals.length);
      }
  }
}

export default new ComprehensiveDataEngine();
