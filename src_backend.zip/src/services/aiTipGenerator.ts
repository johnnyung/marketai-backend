import signalGeneratorService from './signalGeneratorService.js';
export default signalGeneratorService;
