import { Pool } from 'pg';
import marketDataService from './marketDataService.js';
import technicalIndicatorsService from './technicalIndicatorsService.js';
import fmpService from './fmpService.js';
import confidenceAdjustmentService from './confidenceAdjustmentService.js';
import riskValidatorService from './riskValidatorService.js';
import portfolioManagerService from './portfolioManagerService.js';
import volatilityNormalizerService from './volatilityNormalizerService.js';
import corporateQualityService from './corporateQualityService.js';
import paperTradingService from './paperTradingService.js';
import retailInterpretabilityService from './retailInterpretabilityService.js';
import hedgingService from './hedgingService.js';
import tradeArchitectService from './tradeArchitectService.js'; // NEW

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

class SignalGeneratorService {
  
  async processDeepBrainRecommendations(analysis: any) {
    console.log('   💰 Processing Signals with PHFA Layer...');
    await this.processTipAging();

    const picks: any[] = [];
    if (Array.isArray(analysis)) {
        analysis.forEach(p => picks.push(p));
    } else {
        // Support legacy formats if any
        if (analysis.defensive_sector?.picks) this.ingest(picks, analysis.defensive_sector.picks, 'Safe & Steady', 'blue_chip');
        if (analysis.growth_sectors) analysis.growth_sectors.forEach((s: any) => { if(s.picks) this.ingest(picks, s.picks, 'High Growth', 'explosive_growth') });
        if (analysis.crypto_unicorns) this.ingest(picks, analysis.crypto_unicorns, 'Crypto', 'crypto_alpha');
        if (analysis.insider_plays) this.ingest(picks, analysis.insider_plays, 'Insider', 'insider_play');
    }

    const hedge = await hedgingService.calculateHedge(picks);
    if (hedge) picks.push({ ...hedge, tier: 'sector_play', category: 'Portfolio Protection', decision_matrix: { type: 'HEDGE', reason: hedge.reason } });

    await pool.query("UPDATE ai_stock_tips SET status = 'archived' WHERE status = 'active'");

    const tickers = picks.map(p => p.ticker).filter(t => t);
    const pricesMap = await marketDataService.getMultiplePrices(tickers);
    
    let publishedCount = 0;

    for (const pick of picks) {
        if(!pick.ticker) continue;
        const ticker = pick.ticker.toUpperCase().trim();
        const quote = pricesMap.get(ticker);
        let price = quote ? quote.price : 0;
        
        if (!price) {
             const retry = await marketDataService.getStockPrice(ticker);
             if (retry) price = retry.price;
        }

        if (!price || price <= 0) continue;

        let status = 'active';
        let reason = pick.reason;
        let action = pick.action || 'BUY';
        let confidence = pick.confidence || 80;
        let matrix = pick.decision_matrix || {};

        // Health Check
        if (!matrix.health) {
             const health = await corporateQualityService.analyzeHealth(ticker);
             if (!health.passed) { action = 'WATCH'; confidence = 10; reason = `⛔ [HEALTH FAIL] ${health.flags.join(', ')}`; }
             matrix.health = health;
        }

        // Volatility Normalization
        const norm = await volatilityNormalizerService.normalize(confidence);
        confidence = norm.adjusted_score;

        // Technical Profile
        const volProfile = (await technicalIndicatorsService.getTechnicalIndicators(ticker))?.momentumProfile || 'Medium';

        // --- PHFA LAYER INTEGRATION ---
        // Generate the full Battle Plan
        const tradePlan = tradeArchitectService.constructPlan(
            ticker,
            price,
            confidence,
            volProfile,
            pick.tier,
            matrix.engines || {} // Pass engine signals for conditional logic
        );

        // Generate Retail Elements
        const badges = retailInterpretabilityService.generateSimpleTags({ ...pick, ...matrix, action, confidence, tier: pick.tier });
        const eli12 = retailInterpretabilityService.generateELI12({ ...pick, ...matrix, action, confidence, ticker });
        
        matrix.retail_badges = badges;
        matrix.eli12_explanation = eli12;
        
        // Inject PHFA Data into DB Save
        await this.saveToDB(pick, price, action, reason, status, new Date(Date.now()+5*86400000), volProfile, tradePlan.allocation_percent, confidence, tradePlan, matrix);
        if (status === 'active') publishedCount++;
    }
    
    console.log(`   ✅ Published ${publishedCount} PHFA-Enhanced Signals.`);

    if (publishedCount > 0) {
        await paperTradingService.runCycle();
    }
  }

  async generateComprehensiveTips() {
      try {
          const engine = (await import('./comprehensiveDataEngine.js')).default;
          await engine.runComprehensiveCollection();
          return await this.getLatestSignals();
      } catch (e: any) {
          console.error("   ❌ Comprehensive Trigger Failed:", e.message);
          return [];
      }
  }

  private async processTipAging() {
      await pool.query("UPDATE ai_stock_tips SET status = 'expired' WHERE status IN ('active', 'watch_only') AND signal_expiry < NOW()");
  }

  private ingest(target: any[], source: any[], cat: string, tier: string) {
      if(source) source.forEach(p => target.push({ ...p, category: cat, tier }));
  }

  private async saveToDB(pick: any, price: number, action: string, reason: string, status: string, expiry: Date, volProfile: string, allocation: number, confidence: number, plan: any, matrix: any) {
      try {
        await pool.query(`
          INSERT INTO ai_stock_tips
          (ticker, company_name, action, tier, entry_price, target_price, stop_loss,
           expected_gain_percent, confidence, reasoning, status, created_at, signal_expiry,
           volatility_profile, allocation_pct, kelly_score, decision_matrix, phfa_data)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, NOW(), $12, $13, $14, $15, $16, $17)
        `, [
            pick.ticker, pick.category, action, pick.tier,
            price, plan.take_profit_1, plan.stop_loss,
            ((plan.take_profit_1 - price)/price)*100, // Calc gain %
            confidence, reason, status, expiry, volProfile,
            allocation, 0, // Kelly score placeholder
            JSON.stringify(matrix),
            JSON.stringify(plan) // SAVE THE PLAN
        ]);
      } catch(e) { console.error(`DB Error ${pick.ticker}`); }
  }

  async getLatestSignals(limit: number = 50) {
      const res = await pool.query("SELECT * FROM ai_stock_tips WHERE status='active' ORDER BY tier, confidence DESC");
      return res.rows;
  }
  
  async generateDailySignals() { return this.getLatestSignals(); }
}

export default new SignalGeneratorService();
