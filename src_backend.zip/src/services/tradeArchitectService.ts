import portfolioManagerService from './portfolioManagerService.js';

export interface TradePlan {
  entry_primary: number;
  entry_secondary: number;
  stop_loss: number;
  soft_stop: number;
  take_profit_1: number;
  take_profit_2: number;
  take_profit_3: number;
  allocation_percent: number;
  max_allocation: number;
  time_horizon: string;
  expected_catalyst_window: string;
  risk_reward_ratio: number;
  if_then_map: string[];
  advanced_explanation: string;
}

class TradeArchitectService {

  /**
   * Generates a Hedge Fund-grade Trade Plan using Deep Brain signals.
   */
  constructPlan(
    ticker: string,
    price: number,
    confidence: number,
    volProfile: 'High' | 'Medium' | 'Low',
    tier: string,
    engines: any // The Deep Brain Signal Matrix
  ): TradePlan {
    
    // --- 1. EXTRACT DEEP BRAIN SIGNALS ---
    const gamma = engines.gamma?.volatility_regime || 'NEUTRAL'; // AMPLIFIED | SUPPRESSED
    const shadow = engines.shadow?.bias || 'NEUTRAL'; // ACCUMULATION | DISTRIBUTION
    const narrative = engines.narrative?.pressure_score || 50; // 0-100
    const regime = engines.regime?.current_regime || 'NEUTRAL'; // RISK_ON | RISK_OFF
    const insider = engines.insider?.classification || 'UNKNOWN';
    const divergence = engines.fractal?.divergence_type || 'NONE';

    // --- 2. CALCULATE BASE VOLATILITY (ATR Proxy) ---
    // If we don't have real ATR, we approximate using price & tier
    let volatilityPct = 0.04; // Default 4%
    if (volProfile === 'High') volatilityPct = 0.08;
    if (volProfile === 'Low') volatilityPct = 0.02;
    
    // Gamma Adjustment: Negative Gamma (Amplified) = Wider Stops needed
    if (gamma === 'AMPLIFIED') volatilityPct *= 1.5;
    // Gamma Adjustment: Positive Gamma (Suppressed) = Tighter Stops allowed
    if (gamma === 'SUPPRESSED') volatilityPct *= 0.8;

    // --- 3. STOP LOSS LOGIC ---
    const stopDist = price * volatilityPct;
    let stopLoss = Number((price - stopDist).toFixed(2));
    
    // If Hidden Bullish Divergence exists, stop goes just below the fractal low (tighter)
    if (divergence === 'HIDDEN_BULL') {
        stopLoss = Number((price - (stopDist * 0.7)).toFixed(2));
    }

    const softStop = Number((price - (stopDist * 0.6)).toFixed(2)); // Mental check

    // --- 4. ENTRY LOGIC ---
    // If Shadow Accumulation is active, Buy Market (Primary = Price)
    // If Shadow is Neutral, prefer limit order at support (Secondary)
    let entryPrimary = price;
    let entrySecondary = Number((price * 0.98).toFixed(2)); // 2% Pullback default

    if (shadow === 'ACCUMULATION') {
        entrySecondary = Number((price * 0.99).toFixed(2)); // Aggressive entry
    } else if (regime === 'RISK_OFF') {
        // In bad macro, demand deeper pullback
        entrySecondary = Number((price * 0.95).toFixed(2));
    }

    // --- 5. TAKE PROFIT LOGIC (Scaling) ---
    const risk = price - stopLoss;
    
    // Targets scale based on Narrative Pressure (Hype)
    let rewardMult = 1.0;
    if (narrative > 75) rewardMult = 1.3; // Hype extends runs
    if (regime === 'RISK_OFF') rewardMult = 0.7; // Compression in bear market

    const tp1 = Number((price + (risk * 1.5 * rewardMult)).toFixed(2));
    const tp2 = Number((price + (risk * 3.0 * rewardMult)).toFixed(2));
    const tp3 = Number((price + (risk * 5.0 * rewardMult)).toFixed(2)); // Moonbag

    // --- 6. POSITION SIZING ---
    // Base allocation from Portfolio Manager
    const baseAlloc = portfolioManagerService.calculateAllocation(tier, confidence, volProfile);
    let allocPct = baseAlloc.pct;

    // Adjust for Insider Intent (Conviction Multiplier)
    if (insider === 'OPPORTUNISTIC' || insider === 'COORDINATED') {
        allocPct = Math.min(allocPct * 1.25, 10); // Cap at 10%
    }
    
    // Adjust for Macro Regime
    if (regime === 'STAGFLATION' || regime === 'RECESSION') {
        allocPct *= 0.5; // Cut size in bad macro
    }

    const maxAlloc = Number((allocPct * 1.5).toFixed(1)); // Room to add

    // --- 7. IF/THEN DECISION MAP ---
    const ifThen: string[] = [];

    // Volatility Logic
    if (gamma === 'AMPLIFIED') {
        ifThen.push(`IF VIX > 30, THEN Reduce Size by 50% (Gamma Trap Risk).`);
    }
    if (gamma === 'SUPPRESSED') {
        ifThen.push(`IF Price > $${tp1}, THEN Trail Stop to Breakeven (Breakout Mode).`);
    }

    // Flow Logic
    if (shadow === 'ACCUMULATION') {
        ifThen.push(`IF Price dips to $${entrySecondary}, ADD (Whales supporting).`);
    } else {
        ifThen.push(`IF Price closes < $${softStop}, EXIT half position.`);
    }

    // Momentum Logic
    if (narrative > 80) {
        ifThen.push(`IF Volume drops -20%, TAKE PROFIT immediately (Hype fading).`);
    }

    // --- 8. METRICS & EXPLANATION ---
    const rrRatio = Number(((tp2 - price) / (price - stopLoss)).toFixed(2));
    
    let horizon = "1-4 Weeks";
    if (tier === 'blue_chip') horizon = "3-12 Months";
    if (engines.catalyst?.has_catalyst) horizon = "Event Driven (Days)";

    const advancedEx = `
      Alpha Setup: ${divergence !== 'NONE' ? divergence : 'Trend'} strategy.
      Risk Profile: ${volProfile} Volatility with ${gamma} Gamma Regime.
      Edge: ${insider === 'OPPORTUNISTIC' ? 'Insider Alignment' : 'Statistical Reversion'}.
      Stop placed at ${stopLoss} based on ${volatilityPct*100}% implied move.
      Targeting ${rrRatio}R via ${narrative > 70 ? 'Momentum Expansion' : 'Value Realization'}.
    `.trim();

    return {
      entry_primary: entryPrimary,
      entry_secondary: entrySecondary,
      stop_loss: stopLoss,
      soft_stop: softStop,
      take_profit_1: tp1,
      take_profit_2: tp2,
      take_profit_3: tp3,
      allocation_percent: parseFloat(allocPct.toFixed(1)),
      max_allocation: maxAlloc,
      time_horizon: horizon,
      expected_catalyst_window: engines.catalyst?.catalyst_event || 'Price Action',
      risk_reward_ratio: rrRatio,
      if_then_map: ifThen,
      advanced_explanation: advancedEx
    };
  }
}

export default new TradeArchitectService();
