// backend/src/services/intelligenceThreadsService.ts
// AI-Powered Intelligence Thread Detection and Management

import Anthropic from '@anthropic-ai/sdk';
import { Pool } from 'pg';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || process.env.CLAUDE_API_KEY
});

interface ThreadCreationCandidate {
  entries: any[];
  theme: string;
  confidence: number;
  reasoning: string;
}

class IntelligenceThreadsService {
  
  /**
   * Main thread detection - analyzes recent entries for connections
   */
  async detectAndCreateThreads(): Promise<number> {
    console.log('🧵 Starting thread detection...');
    
    // Get recent high-priority entries not yet in threads
    const entries = await this.getUnthreadedEntries();
    console.log(`  ✓ Found ${entries.length} unthreaded entries`);
    
    if (entries.length < 3) {
      console.log('  ⚠️  Not enough entries for thread detection');
      return 0;
    }
    
    // Use AI to detect potential threads
    const candidates = await this.detectThreadCandidates(entries);
    console.log(`  ✓ Detected ${candidates.length} potential threads`);
    
    // Create threads for high-confidence candidates
    let threadsCreated = 0;
    for (const candidate of candidates) {
      if (candidate.confidence >= 70 && candidate.entries.length >= 3) {
        await this.createThread(candidate);
        threadsCreated++;
      }
    }
    
    console.log(`  ✅ Created ${threadsCreated} new threads`);
    return threadsCreated;
  }
  
  /**
   * Get unthreaded high-priority entries from last 7 days
   */
  private async getUnthreadedEntries() {
    const result = await pool.query(`
      SELECT 
        e.id,
        e.source_type,
        e.source_name,
        e.ai_summary,
        e.ai_relevance_score,
        e.ai_sentiment,
        e.ai_entities_tickers,
        e.event_date
      FROM digest_entries e
      WHERE e.event_date >= NOW() - INTERVAL '7 days'
        AND e.ai_relevance_score >= 70
        AND NOT EXISTS (
          SELECT 1 FROM thread_events te WHERE te.entry_id = e.id
        )
      ORDER BY e.ai_relevance_score DESC, e.event_date DESC
      LIMIT 100
    `);
    
    return result.rows;
  }
  
  /**
   * Use AI to detect thread candidates from entries
   */
  private async detectThreadCandidates(entries: any[]): Promise<ThreadCreationCandidate[]> {
    const entriesSummary = entries.map(e => 
      `[${e.id}] ${e.event_date.toISOString().split('T')[0]} | ${e.source_name}: ${e.ai_summary} (Score: ${e.ai_relevance_score})`
    ).join('\n');
    
    const prompt = `You are an expert market analyst detecting connected intelligence threads.

RECENT INTELLIGENCE ENTRIES:
${entriesSummary}

Analyze these entries and identify groups of 3+ events that are meaningfully connected - telling a coherent market story.

Look for:
- Cause-and-effect relationships
- Similar themes/sectors
- Geopolitical connections
- Supply chain linkages
- Regulatory domino effects
- Market sentiment shifts

For each thread you detect, provide:
- Which entry IDs belong together
- The connecting theme
- Confidence (0-100) this is a real pattern
- Brief reasoning why they're connected

Respond with ONLY valid JSON:
{
  "threads": [
    {
      "entry_ids": [123, 124, 125],
      "theme": "Brief theme description",
      "confidence": 85,
      "reasoning": "Why these events are connected"
    }
  ]
}`;

    try {
      const message = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 3000,
        messages: [{ role: 'user', content: prompt }]
      });
      
      const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
      const cleaned = responseText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const parsed = JSON.parse(cleaned);
      
      // Map entry IDs back to full entries
      const candidates: ThreadCreationCandidate[] = [];
      for (const thread of parsed.threads || []) {
        const threadEntries = entries.filter(e => thread.entry_ids.includes(e.id));
        if (threadEntries.length >= 3) {
          candidates.push({
            entries: threadEntries,
            theme: thread.theme,
            confidence: thread.confidence,
            reasoning: thread.reasoning
          });
        }
      }
      
      return candidates;
    } catch (error) {
      console.error('AI thread detection failed:', error);
      return [];
    }
  }
  
  /**
   * Create a new thread with AI-generated insights
   */
  private async createThread(candidate: ThreadCreationCandidate): Promise<number> {
    console.log(`  📝 Creating thread: ${candidate.theme}`);
    
    // Generate comprehensive thread analysis with AI
    const analysis = await this.generateThreadAnalysis(candidate);
    
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      
      // Create thread
      const threadResult = await client.query(`
        INSERT INTO intelligence_threads (
          title, theme, status, ai_insight, ai_trading_implication,
          ai_risk_factors, affected_tickers, event_count,
          first_event_date, last_event_date, risk_level, confidence_score
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        RETURNING id
      `, [
        analysis.title,
        candidate.theme,
        'ACTIVE',
        analysis.insight,
        analysis.tradingImplication,
        analysis.riskFactors,
        JSON.stringify(analysis.affectedTickers),
        candidate.entries.length,
        candidate.entries[candidate.entries.length - 1].event_date,
        candidate.entries[0].event_date,
        analysis.riskLevel,
        candidate.confidence
      ]);
      
      const threadId = threadResult.rows[0].id;
      
      // Link all entries to thread
      for (const entry of candidate.entries) {
        await client.query(`
          INSERT INTO thread_events (thread_id, entry_id, relevance_score)
          VALUES ($1, $2, $3)
        `, [threadId, entry.id, entry.ai_relevance_score]);
      }
      
      await client.query('COMMIT');
      console.log(`  ✅ Created thread #${threadId}: ${analysis.title}`);
      
      return threadId;
    } catch (error) {
      await client.query('ROLLBACK');
      console.error('Failed to create thread:', error);
      throw error;
    } finally {
      client.release();
    }
  }
  
  /**
   * Generate comprehensive thread analysis with AI
   */
  private async generateThreadAnalysis(candidate: ThreadCreationCandidate) {
    const entriesContext = candidate.entries.map(e => 
      `${e.event_date.toISOString().split('T')[0]}: ${e.ai_summary}`
    ).join('\n');
    
    const prompt = `You are analyzing a connected intelligence thread in financial markets.

THEME: ${candidate.theme}

CONNECTED EVENTS:
${entriesContext}

Create a comprehensive thread analysis:

1. TITLE: Compelling 6-10 word thread title
2. INSIGHT: 2-3 sentence analysis of what's happening and why it matters
3. TRADING IMPLICATION: Specific actionable trading insight (2-3 sentences)
4. RISK FACTORS: 3-5 specific risks to watch
5. AFFECTED TICKERS: List of stock tickers most impacted
6. RISK LEVEL: LOW, MEDIUM, HIGH, or CRITICAL

Be specific, actionable, and insightful.

Respond with ONLY valid JSON:
{
  "title": "Thread title",
  "insight": "What's happening and why it matters",
  "tradingImplication": "Specific trading action or consideration",
  "riskFactors": ["risk 1", "risk 2", "risk 3"],
  "affectedTickers": ["AAPL", "MSFT"],
  "riskLevel": "HIGH"
}`;

    try {
      const message = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2000,
        messages: [{ role: 'user', content: prompt }]
      });
      
      const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
      const cleaned = responseText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const parsed = JSON.parse(cleaned);
      
      return parsed;
    } catch (error) {
      console.error('AI analysis generation failed:', error);
      // Return fallback
      return {
        title: candidate.theme,
        insight: 'Multiple related events detected. Further analysis in progress.',
        tradingImplication: 'Monitor developments closely.',
        riskFactors: ['Market volatility', 'Uncertain outcomes', 'Timing unclear'],
        affectedTickers: [],
        riskLevel: 'MEDIUM'
      };
    }
  }
  
  /**
   * Get all active threads
   */
  async getActiveThreads() {
    const result = await pool.query(`
      SELECT 
        id, title, theme, status, ai_insight, ai_trading_implication,
        ai_risk_factors, affected_tickers, event_count,
        first_event_date, last_event_date, risk_level,
        confidence_score, created_at, updated_at
      FROM intelligence_threads
      WHERE status IN ('ACTIVE', 'MONITORING')
      ORDER BY last_event_date DESC, confidence_score DESC
      LIMIT 20
    `);
    
    return result.rows;
  }
  
  /**
   * Get thread by ID with all events
   */
  async getThreadById(threadId: number) {
    // Get thread details
    const threadResult = await pool.query(`
      SELECT 
        id, title, theme, status, ai_insight, ai_trading_implication,
        ai_risk_factors, affected_tickers, event_count,
        first_event_date, last_event_date, risk_level,
        confidence_score, created_at, updated_at
      FROM intelligence_threads
      WHERE id = $1
    `, [threadId]);
    
    if (threadResult.rows.length === 0) {
      return null;
    }
    
    const thread = threadResult.rows[0];
    
    // Get all events in thread
    const eventsResult = await pool.query(`
      SELECT 
        e.id as entry_id,
        e.source_name,
        e.ai_summary,
        e.event_date,
        te.relevance_score
      FROM thread_events te
      JOIN digest_entries e ON te.entry_id = e.id
      WHERE te.thread_id = $1
      ORDER BY e.event_date DESC
    `, [threadId]);
    
    return {
      ...thread,
      events: eventsResult.rows
    };
  }
  
  /**
   * Update thread status
   */
  async updateThreadStatus(threadId: number, status: string): Promise<void> {
    await pool.query(`
      UPDATE intelligence_threads
      SET status = $1, updated_at = NOW()
      WHERE id = $2
    `, [status, threadId]);
  }
}

export default new IntelligenceThreadsService();
